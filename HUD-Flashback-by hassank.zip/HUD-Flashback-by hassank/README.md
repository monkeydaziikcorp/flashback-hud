# HUD-Flashback par !HassanK#6666

Bonjour à tous je vous présente aujourd'hui une petite modification du [esx_customui](https://github.com/ItsikNox/FiveM-Arkadia_/tree/master/resources/%5Bhud%5D/esx_customui) du même style que l'HUD du très célèbre serveur Flashback !

# Preview

 - 🎥 [Vidéo Preview HUD](https://streamable.com/477a6f)
 
 ![screenshot](https://media.discordapp.net/attachments/723268302255816724/862103945080995860/FlashbackHUD.PNG)
 
# Requirements

- [esx_basicneeds]
- [esx_status]